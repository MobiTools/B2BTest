export { default } from './BannerSlider';
