export { default } from "./NewsBanner";
