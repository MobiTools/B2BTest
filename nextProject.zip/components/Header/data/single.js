const navData = ["home", "about", "contact", "news"];

export default navData;
