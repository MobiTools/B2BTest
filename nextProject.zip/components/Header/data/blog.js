import sample from './sample-pages';

const multiple = [
  {
    name: 'Category 1',
    child: [
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      },
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      },
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      },
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      }
    ]
  },
  {
    name: 'Category 2',
    child: [
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      },
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      },
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      },
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      }
    ]
  },
  {
    name: 'Category 3',
    child: [
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      },
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      },
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      },
      {
        name: 'Eu Rhoncus Odio',
        link: '/'
      }
    ]
  },
  {
    name: 'Sample Pages',
    child: sample
  }
];

export default multiple;
