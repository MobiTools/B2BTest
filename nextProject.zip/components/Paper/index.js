export { default } from "./Paper";
