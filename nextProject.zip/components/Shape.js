import Box from "@mui/material/Box";

export default function Shape({ ...restProps }) {
  return <Box sx={{ ...restProps }}></Box>;
}
