const uiState = {
  header: 'mixed', /* available: mixed, droplist, mega, navscroll, hamburger, basic, search */
  footer: 'sitemap', /* available: basic, blog, contact, sitemap */
  corner: 'chat' /* available: chat, nav */,
};

export default uiState;
