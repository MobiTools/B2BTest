module.exports = {
  starter: {
    name: 'Starter',
    desc: 'Oiron Starter - React Starter Template',
    prefix: 'oiron',
    footerText: 'Oiron Theme All Rights Reserved 2020',
    logoText: 'Oiron Theme',
    projectName: 'Starter Project',
    url: 'oiron.indisains.com',
    img: '/static/images/logo.png',
    notifMsg: 'Donec sit amet nulla sed arcu pulvinar ultricies commodo id ligula.'
  }
};
